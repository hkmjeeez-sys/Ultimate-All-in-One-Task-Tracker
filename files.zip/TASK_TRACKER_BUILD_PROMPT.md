# BUILD PROMPT — "The Ultimate Task Tracker 2.0" (Google Sheets via GWS CLI)

> Companion file: `SPREADSHEET_PROMPT_GENERATOR.md` (defines how the build system works — Values API + batchUpdate, build order, capabilities/limits). Follow its build order exactly.

Build me an all-in-one, ADHD-friendly Task Tracker in Google Sheets with a fully automated dashboard, a formula-driven recurring-task engine, weekly + monthly calendar views, and a smart notifications panel. All formulas must be native Google Sheets — no Apps Script. Style it in soft pastels (pink / blue / mint / lavender / cream) with a dark-slate task table, matching a premium Etsy digital-product aesthetic.

---

## 1. Overview

A productivity tracker for individuals and small teams, designed to be sold as a digital product. Users log every task in one Task Manager tab; the Dashboard auto-generates KPI stats, smart notifications ("5 tasks due tomorrow", "Completed 43% of tasks"), Today's and Overdue panels, four donut charts, a priority-by-category stacked bar, a 14-day activity timeline, and a per-person workload chart. A Recurring Tasks tab is the "auto-repeat" engine: each template computes its next due date from frequency + last-completed date and flags itself 🔔 DUE NOW. Weekly and Monthly views re-render from date selectors. The sheet must look complete and impressive on first open, so seed data must light up every panel, chart, and formatting rule.

---

## 2. Tab Structure

| sheetId | Tab Name | Visible | Purpose |
|---------|----------|---------|---------|
| 0 | Dashboard | Yes | Notifications, KPI strip, Today/Overdue panels, 4 donuts, stacked bar, timeline, workload chart |
| 1 | Task Manager | Yes | Master task log — single source of truth (dark-slate header table) |
| 2 | Recurring Tasks | Yes | Auto-repeat templates with next-due-date engine |
| 3 | Weekly View | Yes | 7-day board driven by week-start selector |
| 4 | Monthly Calendar | Yes | Formula-built calendar grid driven by year/month selectors |
| 5 | Settings | Yes | Editable lists: categories, statuses, priorities, people, frequencies |
| 6 | Helper | **Hidden** | Pre-aggregated chart data tables |

Build order: Settings → Task Manager → Recurring Tasks → Helper → Dashboard → Weekly View → Monthly Calendar. Data before dashboards.

---

## 3. Column Definitions

### Tab: Settings (sheetId 5)

| Range | Content |
|-------|---------|
| A1 | "CATEGORIES" |
| A2:A7 | 🖥️ Work, ❤️ Health, 💰 Finance, 🏠 Home, 🌱 Growth, ⭐ Personal |
| B1 | "STATUSES" |
| B2:B6 | ⬜ To Do, 🔵 In Progress, 🟡 On Hold, ✅ Completed, ❌ Cancelled |
| C1 | "PRIORITIES" |
| C2:C6 | 🔴 Very High, 🟠 High, 🟡 Medium, 🟢 Low, ⚪ Very Low |
| D1 | "PEOPLE" |
| D2:D7 | Alice, Michael, Emily, David, Sophie, Marco |
| F1 | "FREQUENCIES" |
| F2:F5 | Daily, Weekly, Biweekly, Monthly |

Headers: bold white text on `#334155`. Every dropdown in the workbook sources from these ranges so buyers can customize their own lists.

### Tab: Task Manager (sheetId 1)

Row 1 = merged pastel banner A1:J1 "📋 TASK MANAGER — add your tasks below", bold `#1F2937` on `#FBCFE8`, height 40. Row 2 = column headers (white bold 10pt on dark slate `#334155`, matching screenshot table style). Data starts row 3; seed 45 rows (Section 5); fill formula columns to row 150.

| Column | Header | Type | Details |
|--------|--------|------|---------|
| A | TASK NAME | Text | User input |
| B | DESCRIPTION | Text | User input |
| C | CATEGORY | Dropdown | Source `Settings!A2:A7`, strict |
| D | STATUS | Dropdown | Source `Settings!B2:B6`, strict |
| E | PRIORITY | Dropdown | Source `Settings!C2:C6`, strict |
| F | ASSIGNED TO | Dropdown | Source `Settings!D2:D7`, warning mode |
| G | DUE DATE | Date | Format `mm/dd/yyyy` |
| H | DAYS LEFT | Formula | `=IF($G3="","",IF($D3="✅ Completed","✓",$G3-TODAY()))` — fill H3:H150. Negative = overdue (styled red via CF) |
| I | DONE | Checkbox | BOOLEAN checkbox validation, I3:I150 |
| J | NOTES | Text | User input |

Column widths: A=210, B=270, C=110, D=125, E=115, F=110, G=95, H=80, I=55, J=190. Body 10pt, alternating white / `#F8FAFC` banding from row 3.

### Tab: Recurring Tasks (sheetId 2)

Row 1 = merged banner A1:H1: "🔁 RECURRING TASKS — mark a task done by updating LAST COMPLETED; NEXT DUE recalculates automatically." Bold `#1F2937` on `#DDD6FE`, height 40. Row 2 = headers (white on `#334155`). Data starts row 3, seed 10 templates, fill formulas to row 60.

| Column | Header | Type | Details |
|--------|--------|------|---------|
| A | RECURRING TASK | Text | |
| B | CATEGORY | Dropdown | `Settings!A2:A7`, strict |
| C | FREQUENCY | Dropdown | `Settings!F2:F5`, strict |
| D | ASSIGNED TO | Dropdown | `Settings!D2:D7`, warning |
| E | LAST COMPLETED | Date | The user's "mark done" control |
| F | NEXT DUE | Formula | `=IF($E3="","",IFS($C3="Daily",$E3+1,$C3="Weekly",$E3+7,$C3="Biweekly",$E3+14,$C3="Monthly",EDATE($E3,1)))` |
| G | STATUS | Formula | `=IF($F3="","",IF($F3<=TODAY(),"🔔 DUE NOW","📅 Scheduled"))` |
| H | DAYS UNTIL | Formula | `=IF($F3="","",$F3-TODAY())` |

### Tab: Helper (sheetId 6, hidden)

All chart-source tables, fixed rectangles with headers:

| Range | Content |
|-------|---------|
| **Status counts** A1:B6 | A1:B1 headers "Status","Count"; A2:A6 `=Settings!B2`…`B6`; B2:B6 `=COUNTIF('Task Manager'!$D$3:$D,A2)` |
| **Category counts** D1:E7 | D2:D7 `=Settings!A2`…`A7`; E2:E7 `=COUNTIF('Task Manager'!$C$3:$C,D2)` |
| **Priority counts** G1:H6 | G2:G6 `=Settings!C2`…`C6`; H2:H6 `=COUNTIF('Task Manager'!$E$3:$E,G2)` |
| **Overall completion** J1:K3 | J2 "Completed", K2 `=COUNTIF('Task Manager'!$D$3:$D,"✅ Completed")`; J3 "Remaining", K3 `=COUNTA('Task Manager'!$A$3:$A)-K2` |
| **Priority × Category matrix** A10:F16 | A10 blank; B10:F10 = the 5 priorities; A11:A16 = the 6 categories; body B11:F16 `=COUNTIFS('Task Manager'!$C$3:$C,$A11,'Task Manager'!$E$3:$E,B$10)` |
| **14-day activity** A20:C34 | A20:C20 headers "Date","Due","Completed"; A21:A34 `=TODAY()-13` … `=TODAY()` (format `mmm d`); B21:B34 `=COUNTIFS('Task Manager'!$G$3:$G,$A21)`; C21:C34 `=COUNTIFS('Task Manager'!$G$3:$G,$A21,'Task Manager'!$D$3:$D,"✅ Completed")` |
| **Person workload** E20:G27 | E20:G20 headers "Person","Open","Completed"; E21:E26 `=Settings!D2`…`D7`; F21:F26 `=COUNTIFS('Task Manager'!$F$3:$F,E21,'Task Manager'!$D$3:$D,"<>✅ Completed",'Task Manager'!$D$3:$D,"<>❌ Cancelled")`; G21:G26 `=COUNTIFS('Task Manager'!$F$3:$F,E21,'Task Manager'!$D$3:$D,"✅ Completed")` |

### Tab: Dashboard (sheetId 0)

A canvas laid out to mirror the reference design: notifications + Today + Overdue down the left, KPI strip and charts across the center/right. Fill the whole visible region A1:V60 with `#FDFCFF`; set column A width 20 (gutter), columns B–E ≈ 150 for the sidebar, F onward default.

**Title banner (row 1, merged B1:V1):** "✨ THE ULTIMATE TASK TRACKER — DASHBOARD", 18pt bold `#1F2937` on gradient stand-in `#FBCFE8`, height 52.

**LEFT SIDEBAR:**

- **🔔 NOTIFICATIONS panel** — header B3 (merged B3:E3) "NOTIFICATIONS", bold white on `#8B5CF6`. Three smart-message rows (each merged B:E, wrap text, 10pt, pastel card fills `#EDE9FE`):
  - B4: `="🔸 "&COUNTIFS('Task Manager'!G:G,TODAY()+1,'Task Manager'!D:D,"<>✅ Completed")&" tasks due tomorrow — stay on track!"`
  - B5: `="✅ Completed "&TEXT(IFERROR(COUNTIF('Task Manager'!D:D,"✅ Completed")/COUNTA('Task Manager'!A3:A),0),"0%")&" of tasks ("&COUNTIF('Task Manager'!D:D,"✅ Completed")&" done, "&COUNTA('Task Manager'!A3:A)-COUNTIF('Task Manager'!D:D,"✅ Completed")&" to go)"`
  - B6: `="⚠️ Overdue tasks: "&COUNTIFS('Task Manager'!G:G,"<"&TODAY(),'Task Manager'!G:G,"<>",'Task Manager'!D:D,"<>✅ Completed",'Task Manager'!D:D,"<>❌ Cancelled")&" — knock a few out today!"`
- **📌 TODAY panel** — header B8 (merged B8:E8) "TODAY", bold white on `#EC4899`. B9: `=IFERROR(FILTER('Task Manager'!A3:A&"  "&'Task Manager'!C3:C,'Task Manager'!G3:G=TODAY(),'Task Manager'!D3:D<>"✅ Completed",'Task Manager'!D3:D<>"❌ Cancelled"),"Nothing due today 🎉")` — panel body fill `#FCE7F3`, rows 9–14 reserved.
- **⏰ OVERDUE panel** — header B16 (merged B16:E16) "OVERDUE", bold white on `#EF4444`. B17: `=IFERROR(FILTER(TEXT('Task Manager'!G3:G-TODAY(),"0")&"  "&'Task Manager'!A3:A&"  "&'Task Manager'!C3:C,'Task Manager'!G3:G<TODAY(),'Task Manager'!G3:G<>"",'Task Manager'!D3:D<>"✅ Completed",'Task Manager'!D3:D<>"❌ Cancelled"),"No overdue tasks ✅")` — leading number is negative days (matches screenshot's "-32" style), panel fill `#FEE2E2`, rows 17–24 reserved.

**KPI STRIP (rows 3–4, columns G–V, eight 2-col cards; label row 3 at 9pt bold `#6B7280`, value row 4 at 18pt bold `#1F2937`, centered):**

| Cells | Label | Value formula | Card fill |
|-------|-------|---------------|-----------|
| G3:H4 | TOTAL TASKS | `=COUNTA('Task Manager'!A3:A)` | `#EDE9FE` |
| I3:J4 | OVERALL COMPLETION | `=IFERROR(COUNTIF('Task Manager'!D:D,"✅ Completed")/COUNTA('Task Manager'!A3:A),0)` fmt `0.0%` | `#D1FAE5` |
| K3:L4 | ONGOING | `=COUNTIF('Task Manager'!D:D,"🔵 In Progress")` | `#DBEAFE` |
| M3:N4 | COMPLETED | `=COUNTIF('Task Manager'!D:D,"✅ Completed")` | `#D1FAE5` |
| O3:P4 | OVERDUE | same COUNTIFS as notification B6 | `#FEE2E2` |
| Q3:R4 | DUE TODAY | `=COUNTIFS('Task Manager'!G:G,TODAY(),'Task Manager'!D:D,"<>✅ Completed")` | `#FEF3C7` |
| S3:T4 | DUE ≤ 7 DAYS | `=COUNTIFS('Task Manager'!G:G,">"&TODAY(),'Task Manager'!G:G,"<="&TODAY()+7,'Task Manager'!D:D,"<>✅ Completed")` | `#FCE7F3` |
| U3:V4 | DUE ≤ 14 DAYS | `=COUNTIFS('Task Manager'!G:G,">"&TODAY(),'Task Manager'!G:G,"<="&TODAY()+14,'Task Manager'!D:D,"<>✅ Completed")` | `#FBCFE8` |

Row 5, merged I5:J5 under the completion card: REPT progress bar `=REPT("█",ROUND(I4*15))&REPT("░",15-ROUND(I4*15))`, text `#8B5CF6`.

**CHART ZONES (empty cell regions reserved as anchors):** donuts row band rows 6–19 (G6, K6, O6, S6); stacked bar + timeline band rows 21–35 (G21, O21); workload band rows 37–50 (G37). See Section 7.

### Tab: Weekly View (sheetId 3)

- Row 1 merged A1:G1 banner "🗓️ WEEKLY VIEW" on `#BFDBFE`, height 40.
- A2: "Week starting (Monday):" — **B2 input cell**, seed with the literal date of this week's Monday (compute `TODAY()-WEEKDAY(TODAY(),3)` at build time, write as value), fill `#FEF3C7`.
- Row 4 day headers A4:G4: A4 `=$B$2` … G4 `=$B$2+6`, format `ddd, mmm d`, white bold on `#334155`.
- Row 5 task lists A5:G5 (wrap ON, vertical TOP, height 300): `=IFERROR(TEXTJOIN(CHAR(10),TRUE,FILTER('Task Manager'!$A$3:$A,'Task Manager'!$G$3:$G=A$4,'Task Manager'!$D$3:$D<>"❌ Cancelled")),"—")` per column.
- Row 6 counts A6:G6: `=COUNTIFS('Task Manager'!$G$3:$G,A$4)`, custom format `0" tasks"`, 9pt `#6B7280`.
- Columns A–G width 150. Alternate column fills white / `#F8FAFC`.

### Tab: Monthly Calendar (sheetId 4)

- Row 1 merged A1:G1 dynamic banner: `="🗓️ "&UPPER(TEXT(DATE($J$2,$J$3,1),"mmmm yyyy"))&" — MONTHLY CALENDAR"`, bold on `#A7F3D0`, height 40.
- **Selectors:** I2 label "Year", **J2 input** seed `2026` (validation NUMBER_BETWEEN 2024–2035); I3 label "Month", **J3 input** seed `7` (NUMBER_BETWEEN 1–12). Both fill `#FEF3C7`.
- Hidden-style helpers (white text): L2 `=DATE($J$2,$J$3,1)`; L3 `=WEEKDAY($L$2,2)` (Mon=1).
- Row 5: Mon–Sun headers A5:G5, white bold on `#334155`.
- **Grid = 6 week-pairs:** date rows 6/8/10/12/14/16, count rows 7/9/11/13/15/17. Write the exact formula into every date cell (do not rely on autofill). Generic date-cell formula for week w (0-based) and column c (1=A…7=G): `=IFERROR(IF(OR(c-$L$3+1+w*7<1, c-$L$3+1+w*7>DAY(EOMONTH($L$2,0))),"",c-$L$3+1+w*7),"")` — substitute literal `c` and `w` numbers per cell (e.g., A6: c=1,w=0 → `=IFERROR(IF(OR(1-$L$3+1<1,1-$L$3+1>DAY(EOMONTH($L$2,0))),"",1-$L$3+1),"")`).
- Count cell directly below each date (e.g., A7): `=IF(A6="","",IF(COUNTIFS('Task Manager'!$G$3:$G,DATE($J$2,$J$3,A6))=0,"",COUNTIFS('Task Manager'!$G$3:$G,DATE($J$2,$J$3,A6))&" ✦"))`
- Date rows 12pt bold height 26; count rows 9pt `#EC4899` height 20; grid cells white with thin `#E5E7EB` borders; columns A–G width 110.

---

## 4. Formulas & Cross-References (flow summary)

- **Task Manager (rows 3+) is the only task store.** Dashboard KPIs/notifications = COUNTIF/COUNTIFS on it; Today/Overdue panels = FILTER on it; every FILTER wrapped in IFERROR with a friendly empty state.
- **Helper** pre-aggregates every chart series into fixed rectangles so chart source ranges never shift.
- **Weekly / Monthly** read only Task Manager G (Due Date) + D (Status), re-rendering when their yellow input cells change.
- **Recurring Tasks** is self-contained: E → F → G/H chain. It does not insert rows into Task Manager (impossible without Apps Script); the 🔔 DUE NOW flag IS the automation, and the banner tells the user the workflow.
- Use open-ended ranges (`$A$3:$A`, `D:D`) so buyer-added rows flow into everything automatically.

---

## 5. Sample Data

Seed **45 tasks** in Task Manager (rows 3–47) with due dates spanning `TODAY()-14` → `TODAY()+21` (compute literal dates at build time). Distribution must exercise every feature:

- All 6 categories ≥5×; all 5 statuses present; all 5 priorities present; all 6 people ≥5×.
- 18 tasks ✅ Completed → completion lands ≈40% (matches the screenshot's "42.8%" vibe).
- Exactly 4 due **today** (not completed) → populates TODAY panel + DUE TODAY KPI.
- Exactly 6 overdue (past due, status To Do / In Progress / On Hold) → populates OVERDUE panel, row-red CF, and negative DAYS LEFT values.
- ≥2 tasks per day across the trailing 14 days → timeline chart has no empty bars.
- Every person has ≥2 open + ≥1 completed task → workload chart shows both series for all six.
- Every priority×category cell used at least somewhere → stacked bar has full coverage.
- Realistic entries: "Update budget sheet", "Plan weekly tasks", "Grocery run", "Reply to client emails", "Meditation break", "Reconcile bank statement", "Publish YouTube script", "Morning stretch", "File receipts", "Team check-in call", "Organize closet", "Laundry day", "Dentist appointment", "Set savings goal", "Deep clean kitchen", etc. Descriptions 5–12 words; notes on ~⅓ of rows.

Seed **10 recurring templates** (rows 3–12): Daily ×3 ("Inbox zero sweep", "Meditation", "Daily standup"), Weekly ×4 ("Weekly review", "Grocery run", "Content batch day", "Invoice clients"), Biweekly ×1 ("Deep clean office"), Monthly ×2 ("Reconcile books", "Pay subscriptions"). Set LAST COMPLETED dates so exactly **3 show 🔔 DUE NOW** and 7 show 📅 Scheduled.

---

## 6. Visual Design

Palette (pastel Etsy aesthetic from the reference images):

| Meaning | Hex | Name |
|---------|-----|------|
| Pastel pink (banners, cards, chart series) | `#FBCFE8` / `#FCE7F3` | Blush |
| Pink accent (panel headers, counts) | `#EC4899` | Hot pink |
| Pastel blue (banners, cards, series) | `#BFDBFE` / `#DBEAFE` | Baby blue |
| Blue accent (In Progress) | `#3B82F6` | Sky |
| Mint (Completed, success) | `#A7F3D0` / `#D1FAE5` | Mint |
| Green accent | `#10B981` | Emerald |
| Lavender (notifications, cards) | `#DDD6FE` / `#EDE9FE` | Lavender |
| Violet accent (primary headers) | `#8B5CF6` | Violet |
| Cream (inputs, warnings) | `#FEF3C7` | Cream |
| Amber accent (On Hold) | `#F59E0B` | Amber |
| Soft red (overdue) | `#FEE2E2` / `#FECACA` | Rose |
| Red accent | `#EF4444` | Red |
| Dark slate (table headers) | `#334155` | Slate |
| Body text | `#1F2937` | Charcoal |
| Muted text | `#6B7280` | Gray |
| Canvas | `#FDFCFF` | Off-white |

- Table headers (Task Manager, Recurring, Weekly day row, Calendar day row): white bold 10pt on `#334155` — the dark strip against pastels is the signature look from the screenshots.
- Tab banners: bold `#1F2937` on a pastel (pink / lavender / blue / mint rotation), 14–18pt, merged, height 40–52.
- Body: 10pt Arial, alternating white / `#F8FAFC`.
- Number formats — dates `mm/dd/yyyy` (Task Manager) and `ddd, mmm d` (Weekly headers); Days Left plain `0`; Overall Completion `0.0%`.

---

## 7. Charts (all anchored on Dashboard, sheetId 0; all data from Helper, sheetId 6)

1. **Donut — STATUS** — data Helper A1:B6 (`headerCount: 1`), `pieHole: 0.5`. Slice colors in status order: `#D1D5DB`, `#3B82F6`, `#F59E0B`, `#10B981`, `#EF4444`. Legend RIGHT. Anchor G6, ~280×210.
2. **Donut — CATEGORY** — data Helper D1:E7, `pieHole: 0.5`. Colors: `#8B5CF6`, `#EC4899`, `#10B981`, `#F59E0B`, `#3B82F6`, `#FBCFE8`. Legend RIGHT. Anchor K6, ~280×210.
3. **Donut — PRIORITY** — data Helper G1:H6, `pieHole: 0.5`. Colors: `#EF4444`, `#F59E0B`, `#FBBF24`, `#10B981`, `#D1D5DB`. Legend RIGHT. Anchor O6, ~280×210.
4. **Donut — OVERALL COMPLETION** — data Helper J1:K3, `pieHole: 0.6`. Colors: `#10B981` (Completed), `#F3F4F6` (Remaining). Legend BOTTOM. Anchor S6, ~280×210.
5. **Stacked horizontal bar — PRIORITY BY CATEGORY** — data Helper A10:F16 (`headerCount: 1`, first column = category labels), BAR type, `stackedType: STACKED`. Series colors = priority colors from chart 3. Legend TOP. Anchor G21, ~440×260.
6. **Column — TASK ACTIVITY TIMELINE (last 14 days)** — data Helper A20:C34 (`headerCount: 1`), grouped columns: Due `#FBCFE8`, Completed `#A7F3D0`. Legend TOP. Anchor O21, ~440×260.
7. **Column — PERSON WORKLOAD** — data Helper E20:G27 (`headerCount: 1`), grouped: Open `#BFDBFE`, Completed `#A7F3D0`. Legend TOP. Anchor G37, ~440×240.

---

## 8. Conditional Formatting (priority order; 1 = highest)

1. **Task Manager D3:D150** — TEXT_CONTAINS "Completed" → bg `#D1FAE5`, text `#065F46`.
2. **Task Manager D3:D150** — TEXT_CONTAINS "In Progress" → bg `#DBEAFE`, text `#1E40AF`.
3. **Task Manager D3:D150** — TEXT_CONTAINS "On Hold" → bg `#FEF3C7`, text `#92400E`.
4. **Task Manager D3:D150** — TEXT_CONTAINS "Cancelled" → bg `#F3F4F6`, text `#6B7280`.
5. **Task Manager A3:J150** — CUSTOM_FORMULA `=AND($G3<>"",$G3<TODAY(),$D3<>"✅ Completed",$D3<>"❌ Cancelled")` → whole row bg `#FEE2E2`.
6. **Task Manager H3:H150** — NUMBER_LESS 0 → text `#B91C1C` bold (negative days-left, screenshot style).
7. **Task Manager H3:H150** — NUMBER_BETWEEN 0–3 → text `#B45309` bold (due within 3 days).
8. **Task Manager E3:E150** — TEXT_CONTAINS "Very High" → text `#B91C1C` bold.
9. **Recurring G3:G60** — TEXT_CONTAINS "DUE NOW" → bg `#FEE2E2`, text `#B91C1C` bold.
10. **Dashboard O4** (OVERDUE KPI) — NUMBER_GREATER 0 → text `#EF4444` bold.
11. **Monthly Calendar date rows A6:G16** — CUSTOM_FORMULA `=AND(A6<>"",DATE($J$2,$J$3,A6)=TODAY())` → bg `#EDE9FE` bold (highlights today).
12. **Weekly View A6:G6** — NUMBER_GREATER 4 → bg `#FEF3C7` (heavy-day flag).

---

## 9. Interactive Elements

- **Task Manager:** dropdowns C/D/E/F, checkboxes I3:I150.
- **Recurring Tasks:** dropdowns B/C/D; LAST COMPLETED (col E) is the mark-done control.
- **Weekly View B2:** week-start date input (cream cell) — entire board re-renders.
- **Monthly Calendar J2/J3:** year + month inputs (cream cells) — calendar re-renders.
- **Settings tab:** every list column is editable and feeds all dropdowns workbook-wide.
- Convention: every user-input cell = `#FEF3C7` cream fill so buyers instantly know where to type.

## 10. Frozen Rows/Columns

- Task Manager: freeze rows 1–2 (banner + headers) + column A. Banner merge A1:J1 spans the column freeze intersection — so instead freeze rows 1–2 ONLY, no column freeze here (merge/freeze conflict rule).
- Recurring Tasks: freeze rows 1–2.
- Weekly View: freeze rows 1–4.
- Monthly Calendar: freeze rows 1–5.
- Dashboard, Settings, Helper: no freezes.

## Requirements

- `valueInputOption: USER_ENTERED` on every values write so formulas parse.
- All formulas native Google Sheets — no Apps Script, no pivot tables, no images.
- Every FILTER/aggregate wrapped in IFERROR with friendly empty-state text.
- Open-ended ranges so new rows flow into dashboard, charts (via Helper), and calendars automatically.
- Hide Helper after population.
- **Post-build verification checklist:** all 8 KPI cards non-zero; all 3 notification messages render with real numbers; TODAY panel lists 4 tasks; OVERDUE panel lists 6 with negative day counts; all 4 donuts render; stacked bar shows all 6 categories; timeline has bars on all 14 days; workload chart shows all 6 people; 3 recurring rows flagged 🔔 DUE NOW; calendar shows July 2026 with today highlighted; overdue rows in Task Manager are red-tinted with red negative DAYS LEFT.
